document.getElementById('date').innerHTML = new Date().toDateString();
